# WeatherDashboard
A simple weather dashboard with a search function for city, and a pleasant background image that changes to represent the current time, day or night.


URL: https://andrewcodesdontyaknow.github.io/WeatherDashboard/


Screenshot:
<img src="/Users/andrewsmith/Desktop/WeatherDashboard_screenshot.png">
